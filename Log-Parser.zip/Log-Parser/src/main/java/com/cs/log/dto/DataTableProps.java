package com.cs.log.dto;

import org.springframework.data.domain.PageRequest;

public class DataTableProps extends PageRequest{

	private static final long serialVersionUID = 1L;
	
	private Integer start = 0;
	private Integer length = 0;
	
	public DataTableProps() {
		super(1, 10);
	} 
	
	public DataTableProps(int start, int length) {
		super(start, length);
	}
	/**
	 * @return the start
	 */
	public Integer getStart() {
		return start;
	}
	/**
	 * @param start the start to set
	 */
	public void setStart(Integer start) {
		this.start = start;
	}
	/**
	 * @return the length
	 */
	public Integer getLength() {
		return length;
	}
	/**
	 * @param length the length to set
	 */
	public void setLength(Integer length) {
		this.length = length;
	}
	
	
}
