/*
 * Copyright (c) 2018, CS and/or its affiliates. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *
 *   - Neither the name of VirtusaPolaris or the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
 * IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */ 
package com.cs.log.service.util;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

import org.codehaus.jackson.JsonEncoding;
import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonGenerator;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cs.log.service.spi.DataPreparedCallback;
import com.cs.log.service.spi.DataReceiverCallback;
import com.cs.log.util.api.LogFileProcessingStatus;
import com.cs.log.util.api.LogStatus;
import com.cs.log.web.config.PropertyConfigurer;

/**
 * @author Uttam
 *
 */
@Component
public class JsonReader{

	Logger logger = LoggerFactory.getLogger(JsonReader.class);

	@Autowired
	PropertyConfigurer config;

	/**
	 * ThreadLocal thread for storing per request data.
	 */
	private static ThreadLocal<String> FILE = new ThreadLocal<>();


	/**
	 * @param processData
	 */
	public void getUniqueIds(final DataReceiverCallback processData) {

		Set<String> uniqueIds = new HashSet<>();
		try (JsonParser parser = getJsonParser()){

			while (parser.nextToken() != JsonToken.END_ARRAY) {
				while (parser.nextToken() != JsonToken.END_OBJECT) {
					String token = parser.getCurrentName();

					if (Log.ID.equals(token)) {

						parser.nextToken(); 
						String id = parser.getText();  
						uniqueIds.add(id);
					}

					if (uniqueIds.size() > Integer.valueOf(config.getSeqProcessingLimits())){
						List<String>  result = new ArrayList<String>(uniqueIds);
						processData.processData(result);
						uniqueIds.clear();
					}

				}
			}

		} catch (IOException ioex) {

		} 


	}


	/**
	 * @param ids
	 * @return
	 */
	public CompletableFuture<List<Log>> jsonToObjectMapping(List<String> ids) {

		return CompletableFuture.supplyAsync(() -> {

			List<Log> logs = new ArrayList<>();
			try (JsonParser parser = getJsonParser()) {

				while (parser.nextToken() != JsonToken.END_ARRAY) {

					Log log = new Log();
					String id = null;
					while (parser.nextToken() != JsonToken.END_OBJECT) {
						String token = parser.getCurrentName();

						if (Log.ID.equals(token)) {
							parser.nextToken(); 
							id = parser.getText();  
							log.setId(id);
						}

						if (Log.STATUS.equals(token)) {
							parser.nextToken();
							String status = parser.getText();
							log.setStatus(status);					
						}

						if (Log.TIMESTAMP.equals(token)) {
							parser.nextToken();
							Long timestamp = parser.getLongValue(); 
							log.setTimestamp(timestamp);					
						}

						if (Log.HOST.equals(token)) {
							parser.nextToken();
							String host = parser.getText(); 
							log.setHost(host);					
						}

						if (Log.TYPE.equals(token)) {
							parser.nextToken();
							String type = parser.getText(); 
							log.setType(type);					
						}

					}

					if(ids.contains(id)){
						logs.add(log);
					}

				}

				return logs;
			} catch (IOException ioex) { }

			return Collections.emptyList();

		});


	}


	/**
	 * @param path
	 * @param fileSize
	 */
	public CompletableFuture<Void> prepareJsonData(final String path, final Long fileSize, DataPreparedCallback callBack) {

		return CompletableFuture.supplyAsync(() -> {
			try {

				JsonGenerator generator = getJsonGenerator(path);
				Random rand = new Random((int) Math.pow(10, 2));

				List<String> statuses = Arrays.asList(new String[]{LogStatus.STARTED.name(),LogStatus.FINISHED.name()});

				generator.writeStartArray();

				for (int i = 0; i < 6000*fileSize; i++){

					for(String status :statuses){

						Integer num = rand.nextInt();

						generator.writeStartObject();
						generator.writeStringField(Log.ID, "EVENT_"+i);
						generator.writeStringField(Log.STATUS, status);
						generator.writeStringField(Log.HOST, Math.abs(num)%2==0?""+Math.abs(num)/1000:null);
						generator.writeStringField(Log.TYPE, Math.abs(num)%2==0?"APPLICATION":null);
						generator.writeNumberField(Log.TIMESTAMP, Math.abs(num));
						generator.writeEndObject();
					}

				}

				generator.writeEndArray();
				generator.close();

				callBack.dataPrepared(LogFileProcessingStatus.SUCCESS.name());
				logger.info("JSON file created successfully at - " + path);

			} catch (IOException ioex) {
				ioex.printStackTrace();
			} 

			return null;
			
		});

	}


	/**
	 * @param filePath
	 * @return
	 * @throws IOException
	 */
	private JsonGenerator getJsonGenerator(final String filePath) throws IOException {
		JsonFactory jsonfactory = new JsonFactory();
		File jsonDoc = new File(filePath);
		JsonGenerator generator = jsonfactory.createJsonGenerator(jsonDoc, JsonEncoding.UTF8);
		return generator;
	}




	/**
	 * @param fileName
	 */
	public  void setFileName(final String fileName){
		FILE.set(fileName);
	}

	/**
	 * @return
	 */
	public static File getFile(){
		return new File(FILE.get()); 
	}

	/**
	 * @return
	 * @throws IOException
	 * @throws JsonParseException
	 */
	protected static JsonParser getJsonParser() throws IOException, JsonParseException {
		JsonFactory jsonfactory = new JsonFactory();
		JsonParser parser = jsonfactory.createJsonParser(getFile());
		return parser;
	}

}

