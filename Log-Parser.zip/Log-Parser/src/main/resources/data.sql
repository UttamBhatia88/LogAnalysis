 INSERT INTO log (id, logid, duration, host,applType,alert) VALUES
  (1,'log100',4000,'uttam@hedani.com','APPLICATION', true);